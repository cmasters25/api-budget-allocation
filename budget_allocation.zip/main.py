import os
from fastapi import FastAPI
from pydantic import BaseModel
from litellm import completion, completion_cost
import traceback

app = FastAPI()

os.environ["OPENAI_API_KEY"] = "REPLACE WITH KEY" #need to replace with correct keys to work
os.environ["ANTHROPIC_API_KEY"] = "REPLACE WITH KEY"
os.environ["DEEPSEEK_API_KEY"] = "REPLACE WITH KEY"
os.environ["XAI_API_KEY"] = "REPLACE WITH KEY"

team_budgets = {
    "team 1": 20.0,
    "team 2": 20.0,
    "team 3": 20.0,
    "team 4": 20.0
}

team_spend = {
    "team 1": 0,
    "team 2": 0,
    "team 3": 0,
    "team 4": 0
}

class ChatRequest(BaseModel):
    team: str
    provider: str
    model: str
    message: str


@app.post("/chat")
def chat(request: ChatRequest):

    team = request.team

    if team not in team_budgets:
        return {"error": "Unknown team"}

    remaining = team_budgets[team] - team_spend[team]

    if remaining <= 0:
        return {
            "status": "blocked",
            "error": "budget reached",
            "remaining_budget": 0
        }

    try:
        response = completion(
            model=f"{request.provider}/{request.model}",
            messages=[
                {"role": "user", "content": request.message}
            ]
        )

        cost = completion_cost(completion_response=response)

        team_spend[team] += cost

        return {
            "status": "allowed",
            "response": response.choices[0].message.content,
            "team": team,
            "provider": request.provider,
            "model": request.model,
            "cost": cost,
            "spent": team_spend[team],
            "remaining": team_budgets[team] - team_spend[team]
        }

    except Exception as e:
        return {"error": str(e)}